// Change to Spanish
changeLanguage('es');

// Change to English  
changeLanguage('en');

// Change to Arabic
changeLanguage('ar');