const translations = {
    en: { /* traducciones en inglés */ },
    es: { /* traducciones en español */ },
    ar: { /* traducciones en árabe */ }
};