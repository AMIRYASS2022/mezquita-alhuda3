document.querySelector('.language-btn').addEventListener('click', function() {
    document.querySelector('.language-dropdown').classList.toggle('active');
});

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const languageSelector = document.querySelector('.language-selector');
    if (!languageSelector.contains(event.target)) {
        document.querySelector('.language-dropdown').classList.remove('active');
    }
});

// Handle language selection
document.querySelectorAll('.language-options button').forEach(button => {
    button.addEventListener('click', function() {
        // Remove active class from all buttons
        document.querySelectorAll('.language-options button').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to clicked button
        this.classList.add('active');
        
        // Update current language display
        const currentLang = document.querySelector('.current-lang');
        currentLang.textContent = this.textContent.substring(0, 2).toUpperCase();
        
        // Close dropdown
        document.querySelector('.language-dropdown').classList.remove('active');
    });
});